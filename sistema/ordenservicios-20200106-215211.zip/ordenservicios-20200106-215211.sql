-- MySQL dump 10.16  Distrib 10.1.41-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ordenservicios
-- ------------------------------------------------------
-- Server version	10.1.41-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_Clientes`
--

DROP TABLE IF EXISTS `t_Clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Clientes` (
  `id_clientes` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  PRIMARY KEY (`id_clientes`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Clientes`
--

LOCK TABLES `t_Clientes` WRITE;
/*!40000 ALTER TABLE `t_Clientes` DISABLE KEYS */;
INSERT INTO `t_Clientes` VALUES (1,'Banamex'),(2,'Nacional Monte De Piedad'),(3,'BBVA Bancomer');
/*!40000 ALTER TABLE `t_Clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Equipo`
--

DROP TABLE IF EXISTS `t_Equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Equipo` (
  `id_epo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_serie` varchar(45) NOT NULL,
  `num_inv` varchar(45) DEFAULT NULL,
  `num_parte` varchar(45) DEFAULT NULL,
  `existencia` int(10) unsigned NOT NULL,
  `id_tipo_componente` int(10) unsigned NOT NULL,
  `id_marca` int(10) unsigned NOT NULL,
  `id_modelo` int(10) unsigned NOT NULL,
  `comentarios` text,
  PRIMARY KEY (`id_epo`),
  UNIQUE KEY `num_serie` (`num_serie`),
  KEY `id_tipo_componente` (`id_tipo_componente`),
  KEY `id_marca` (`id_marca`),
  KEY `id_modelo` (`id_modelo`),
  CONSTRAINT `t_Equipo_ibfk_1` FOREIGN KEY (`id_tipo_componente`) REFERENCES `t_Tipo_Componente` (`id_tipo_componente`) ON UPDATE CASCADE,
  CONSTRAINT `t_Equipo_ibfk_2` FOREIGN KEY (`id_marca`) REFERENCES `t_Marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `t_Equipo_ibfk_3` FOREIGN KEY (`id_modelo`) REFERENCES `t_Modelo` (`id_modelo`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Equipo`
--

LOCK TABLES `t_Equipo` WRITE;
/*!40000 ALTER TABLE `t_Equipo` DISABLE KEYS */;
INSERT INTO `t_Equipo` VALUES (1,'7410HH348984','Numero De Inventario 1','40X4598',1,1,1,1,NULL),(2,'7410HH348993','Numero De Inventario 2','NUMPARTE10',2,2,1,1,NULL),(3,'9410HH348081','Numero De Inventario 3','NUMPARTE20',4,1,1,1,NULL),(4,'NUMERO SERIE 1','NUMERO INVENTARIO 1','NUMERO DE PARTE 1',1,4,1,2,''),(6,'NUMERO DE SERIE 2','NUMERO DE INVENTARIO 2','NUMERO DE PARTE 2',2,2,1,1,'COMENTARIOS 2'),(8,'NUMERO DE SERIE 4','NUMERO DE INVENTARIO 4','NUMERO DE PARTE 4',4,3,3,4,'COMENTARIO 4');
/*!40000 ALTER TABLE `t_Equipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Historico_epo`
--

DROP TABLE IF EXISTS `t_Historico_epo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Historico_epo` (
  `id_Historico_epo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_marca` int(10) unsigned NOT NULL,
  `id_modelo` int(10) unsigned NOT NULL,
  `id_clientes` int(10) unsigned NOT NULL,
  `id_sucursal` int(10) unsigned NOT NULL,
  `id_epo` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  `notas` text,
  PRIMARY KEY (`id_Historico_epo`),
  KEY `id_marca` (`id_marca`),
  KEY `id_modelo` (`id_modelo`),
  KEY `id_clientes` (`id_clientes`),
  KEY `id_sucursal` (`id_sucursal`),
  KEY `id_epo` (`id_epo`),
  CONSTRAINT `t_Historico_epo_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `t_Marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `t_Historico_epo_ibfk_2` FOREIGN KEY (`id_modelo`) REFERENCES `t_Modelo` (`id_modelo`) ON UPDATE CASCADE,
  CONSTRAINT `t_Historico_epo_ibfk_3` FOREIGN KEY (`id_clientes`) REFERENCES `t_Clientes` (`id_clientes`) ON UPDATE CASCADE,
  CONSTRAINT `t_Historico_epo_ibfk_4` FOREIGN KEY (`id_sucursal`) REFERENCES `t_Sucursales` (`id_sucursal`) ON UPDATE CASCADE,
  CONSTRAINT `t_Historico_epo_ibfk_5` FOREIGN KEY (`id_epo`) REFERENCES `t_Equipo` (`id_epo`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Historico_epo`
--

LOCK TABLES `t_Historico_epo` WRITE;
/*!40000 ALTER TABLE `t_Historico_epo` DISABLE KEYS */;
INSERT INTO `t_Historico_epo` VALUES (1,1,1,1,1,1,'2018-05-19','Campo De Notas 1'),(2,1,1,1,1,1,'2018-06-20','Campo De Notas 2'),(3,1,1,1,1,1,'2018-07-19','Campo De Notas 3');
/*!40000 ALTER TABLE `t_Historico_epo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Marca`
--

DROP TABLE IF EXISTS `t_Marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Marca` (
  `id_marca` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Marca`
--

LOCK TABLES `t_Marca` WRITE;
/*!40000 ALTER TABLE `t_Marca` DISABLE KEYS */;
INSERT INTO `t_Marca` VALUES (1,'HewllwtPackard'),(2,'Dell'),(3,'Lexmark'),(4,'BIXELON'),(5,'NO APLICA');
/*!40000 ALTER TABLE `t_Marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Modelo`
--

DROP TABLE IF EXISTS `t_Modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Modelo` (
  `id_modelo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Modelo`
--

LOCK TABLES `t_Modelo` WRITE;
/*!40000 ALTER TABLE `t_Modelo` DISABLE KEYS */;
INSERT INTO `t_Modelo` VALUES (1,'MX711'),(2,'MX611'),(3,'Optiplex 970'),(4,'MS510'),(5,'MS811'),(6,'MX720'),(7,'MS810'),(8,'C950'),(9,'BIXELON'),(10,'BCD-1000DG'),(11,'OPTIPLEX 9020'),(12,'NO APLICA'),(13,'P2021'),(14,'MS610'),(15,'CS820'),(16,'MX610DN');
/*!40000 ALTER TABLE `t_Modelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Refaccion`
--

DROP TABLE IF EXISTS `t_Refaccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Refaccion` (
  `id_refaccion` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  `num_parte` varchar(45) NOT NULL,
  `existencia` tinyint(4) DEFAULT '1',
  `fecha` date NOT NULL,
  `id_marca` int(10) unsigned NOT NULL,
  `id_modelo` int(10) unsigned NOT NULL,
  `observaciones` text,
  PRIMARY KEY (`id_refaccion`),
  UNIQUE KEY `num_parte` (`num_parte`),
  KEY `id_marca` (`id_marca`),
  KEY `id_modelo` (`id_modelo`),
  CONSTRAINT `t_Refaccion_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `t_Marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `t_Refaccion_ibfk_2` FOREIGN KEY (`id_modelo`) REFERENCES `t_Modelo` (`id_modelo`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Refaccion`
--

LOCK TABLES `t_Refaccion` WRITE;
/*!40000 ALTER TABLE `t_Refaccion` DISABLE KEYS */;
INSERT INTO `t_Refaccion` VALUES (8,'MPF FEEDER  LIFT PLATE WITH CABLE','40X7598',1,'2019-12-27',3,1,'1 - OFICINA'),(10,'ENSAMBLE ALIMENTACION PAPEL','41X0959',1,'2019-12-27',3,2,'OFICINA'),(11,'JAM ACCESS COVER','40X8279',1,'2019-12-27',3,2,'OFICINA'),(12,'PANEL BOARD CONTROL','40X9245',2,'2019-12-27',3,1,'1 - OFICINA\r\n1 - ALMACÉN '),(13,'MEDIA FEEDER ','40X7591',1,'2019-12-27',3,1,'OFICINA'),(14,'MEDIA ALIGNER ROLLER WIHT MPF PICK ROLL ','40X7599',2,'2019-12-27',3,1,'1 - OFICINA'),(15,'UPPER REDRIVER ','40X7602',2,'2019-12-27',3,1,'1 - OFICINA'),(17,'PRINT HEAD','40X7597',1,'2019-12-27',3,1,'1 - OFICINA'),(18,'ROLL TRANSFER ','40X8393',3,'2019-12-27',3,2,'1- OFICINA\r\n2- ALMACÉN CAJA-1\r\n\r\n'),(20,'BIZEL DERECHO BASE TECLADO NUMERICO','40X7865',1,'2019-12-27',3,1,'1 - OFICINA'),(21,'BOTONES DE TECLADO','40X7863',1,'2019-12-27',3,1,'1 - OFICINA'),(22,'HVPS','40X7578',2,'2019-12-27',3,1,'1 - OFICINA\r\n1 - ALMACÉN  '),(23,'MPF GEAR BOX COMPLETO','40X8777',2,'2019-12-27',3,2,'2 - OFICINA\r\nCHECAR A 1 LE FALTA RESORTE INCOMPLETO\r\n'),(24,'FRONT IMPUT GUIDE','40X8280',1,'2019-12-27',3,2,'1 - OFICINA'),(25,'MEDIA TURN GUIDE','40X7583',5,'2019-12-27',3,1,'1 - OFICINA\r\n1 - ALMACÉN CAJA 2\r\n1 - ALMACÉN CAJA 3\r\n2 - ALMACÉN\r\n'),(26,'SENSOR STD BIR FULL WITH OUTPUT BIR GUIDE','40X7691',1,'2019-12-27',3,1,'1 - OFICINA\r\n'),(27,'REDIVER ANSSAMBLED','40X8298',2,'2019-12-27',3,4,'1 - OFICINA 1\r\n1 - ALMACÉN CAJA 2'),(31,'MPF PICKUP ROLLER AND SEPARATOR PAD','40X8295',6,'2019-12-27',3,2,'6 - OFICINA'),(32,'MPF PICK ROLLER','40S7600',4,'2019-12-27',3,1,'OFICINA'),(33,'MPF PICK ROLLER  ASSEMBLY','40X7593',43,'2019-12-27',3,1,'2 - OFICINA\r\n41 - ALMACÉN CAJA 3'),(34,'CONTRACT CARTRIDGE SMART CHIP','40X8266',2,'2019-12-27',3,2,'OFICINA'),(35,'CABLE CONTROL PANEL','40X9052',1,'2019-12-27',3,1,'OFICINA\r\nLES QUEDAN A ESTOS MODELOS\r\n40 x 9052 Lexmark Cable uicc MX410de MX511de MX511dte MX610de MX310dn MX511dte'),(36,'HVPS CONTACT','41X1721',1,'2019-12-27',3,1,'OFICINA'),(37,'SENSOR NARROW MEDIA BIN FULL','40X8050',1,'2019-12-27',3,1,'OFICINA'),(38,'MEDIA PRESENT SENSOR FLAG','40X8800',1,'2019-12-27',3,2,'1 -OFICINA'),(39,'ADF SEPARATOR ROLLER','40X7775',1,'2019-12-27',3,1,'OFICINA'),(40,'DUPLEX GEAR ASSAMBLY','40X8277',1,'2019-12-27',3,2,'OFICINA'),(41,'CONTROL PANEL INTERLOCK SENSOR','40X7693',1,'2019-12-27',3,1,'OFICINA'),(42,'MEDIA SENSOR','41X0259',1,'2019-12-27',3,2,'OFICNA \r\nTAMBIEN LE QUEDA A LAS\r\nMX410, 511 MX610 \r\nDE NUMERO DE PARTE 41X0259'),(43,'PICK  ROLLER ASSEMBLY','40X8443',32,'2019-12-27',3,2,'5 - OFICINA\r\n27 - ALMACÉN CAJA 3'),(44,'TRANSFER ROLL','40X7582',2,'2019-12-27',3,1,'OFICINA'),(45,'HCIT SEPARATOR ROLLER','40X7713',3,'2019-12-27',3,1,'OFICINA'),(47,'SEPARATOR ROLL ASSAMBLY','40X8444',2,'2019-12-27',3,2,'1 - OFICINA\r\n1 - ALMACÉN CAJA 3'),(48,'REDRIVER ASSEMBLY','40X9082',4,'2020-01-06',3,2,'2 - ALMACÉN CAJA 1\r\n1 - ALMACEN CAJA 2\r\n1 - ALMACÉN CAJA 6'),(49,'REDRIVER ASSEMBLY','40X8437',1,'2020-01-06',3,16,'1 - ALMACEN CAJA 1'),(50,'FUSOR','40X8023',4,'2020-01-06',3,2,'1 - OFICINA\r\n1 - ALMACÉN CAJA 1\r\n1 - ALMACÉN CAJA 2\r\n1 - ALMACÉN CAJA 6'),(51,'FUSOR','40X7743',3,'2020-01-06',3,1,'1 - OFICINA\r\n1 - ALMACÉN CAJA 2\r\n1 - ALMACÉN CAJA 6'),(53,'ACTUAR MEDIA SIZE','40X8541',1,'2020-01-06',3,5,'1 - ALMACEN CAJA 3'),(54,'MPH PICK UP ROLLER','40X7600',8,'2020-01-06',3,1,'4 - ALMACÉN CAJA 3\r\n4 - OFICINA\r\n '),(55,'HVPS CONTACT','40X1721',2,'2020-01-06',3,1,'2 - ALMACÉN CAJA 3 '),(56,'BISAGRA ADF ASSEMBLY','40X7763',1,'2020-01-06',3,1,'1 - ALMACEN CAJA 3'),(57,'ADF CONTROLLER BOARD','41X1896',1,'2020-01-06',3,6,'1 - ALMACÉN CAJA 3'),(58,'SVS ROLLER PLASTIC','41X2610',1,'2020-01-06',3,7,'1 - ALMACÉN CAJA 3'),(59,'PRINT FEEDER','40X7662',1,'2020-01-06',3,8,'1 - ALMACÉN CAJA 3'),(60,'HCIT SEPARATION ROLLER','40X1713',83,'2020-01-06',3,1,'83 - ALMACÉN CAJA 3'),(61,'PANTALLA PARA CAJA REGISTRADORA','BCD-1000DG',1,'2020-01-06',4,10,'1 - ALMACÉN CAJA 4'),(62,'COMPUTADORA DE ESCRITORIO','7R5PW52',1,'2020-01-06',2,11,'1 - ALMACÉN CAJA 4\r\n1 - DISCO DURO\r\n1 - MEMORIA\r\n1 - DVD'),(63,'MEDIA TURN GUIDE','40X7589',2,'2020-01-06',3,1,'1 - OFICINA\r\n1 - ALMACÉN CAJA 6\r\nSE ENCUENTRA ESPACIO PARA CAJAS PEQUEÑAS\r\n'),(64,'COMPUTADORA DE ESCRITORIO','17F8KS1',1,'2020-01-06',2,3,'1 - DISCO DURO CAJA 5\r\n2 - MEMORIAS SERVINEXT CAJA 5\r\n1 - PAQUETE CAMISETAS SERVINEXT OCT/19 CAJA 5\r\n'),(65,'CAJA HERRAMIENTA','CAJ-HERR',1,'2020-01-06',5,12,'1 CAJA HERRAMIENTA SERVINEXT\r\n1 CAMISETAS DESDE 24 SEP 18'),(66,'MONITOR','SERIAL MONT',1,'2020-01-06',2,13,'1 - ALMACÉN CAJA 8 \r\nNACIONAL MONTE DE PIEDAD \r\nPROBLEMAS CON EL BOTÓN DE ENCENDIDO'),(67,'KIT MANTTO','1-300675233581',1,'2019-06-21',3,2,'1 - ALMACÉN\r\nPENDIENTE DE ASIGNAR\r\nNUMERO DE PARTE 40X9137'),(68,'KIT MANTTO','1-299991296885',1,'2019-05-24',3,2,'1 - ALMACÉN\r\nPENDIENTE DE ASIGNAR\r\nNUMERO DE PARTE 40X9137'),(69,'KIT MANTTO','301558068329B601142885',1,'2019-07-03',3,14,'1 - ALMACÉN \r\n500540384 - STOCK SERVINEXT\r\nNUMERO DE PARTE 40X8433'),(70,'KIT MANTTO','101558068329B601142886',1,'2019-07-03',3,14,'1 - ALMACÉN \r\n5005403843 - STOCK SERVINEXT \r\nNUMERO DE PARTE 40X8433'),(71,'HVPS CONTACT','40X7121',3,'2019-06-29',3,1,'3 - ALMACÉN '),(72,'PRINT FEEDER','40X6662',1,'2019-06-25',3,8,'1 - ALMACÉN\r\nESTABA EN OFICINA DE GABRIEL SE RECOLECTO'),(73,'SYSTEM BOARD ','40X9234',1,'2018-09-27',3,1,'1 - ALMACÉN '),(74,'FLATBED SCANNER','40X7912',1,'2017-08-09',3,1,'1 - ALMACÉN'),(75,'LVPS','40X7676',1,'2018-09-27',3,1,'1 - ALMACÉN '),(76,'CABLE PANEL CONTROL','40X7873',1,'2018-09-27',3,1,'1 - ALMACÉN'),(77,'FLATBED ASSAMBLY','40X9094',1,'2017-06-28',3,2,'1 -  ALMACÉN\r\nESTABA EN DE OFICINA DE GABRIEL SE RECOLECTO'),(78,'CATRIDGE PLUNGER','40X9148',1,'2019-12-14',3,2,'1 - ALMACÉN '),(79,'ACM ENSAMBLE ALIMENTACION HOJAS','40X0959',1,'2019-11-14',3,2,'1 - ALMACÉN '),(80,'PICKUP  ROLLER TIRE KIT','41X0958',2,'2018-09-27',3,2,'2 - ALMACÉN '),(81,'SENSOR BUMP EXIT APERTURE','41X2278',1,'2018-04-07',3,15,'1 - ALMACÉN\r\n ');
/*!40000 ALTER TABLE `t_Refaccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Rol`
--

DROP TABLE IF EXISTS `t_Rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Rol` (
  `id_rol` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rol` varchar(80) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Rol`
--

LOCK TABLES `t_Rol` WRITE;
/*!40000 ALTER TABLE `t_Rol` DISABLE KEYS */;
INSERT INTO `t_Rol` VALUES (1,'Administrador'),(2,'Supervisor'),(3,'ingenieria');
/*!40000 ALTER TABLE `t_Rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Sucursales`
--

DROP TABLE IF EXISTS `t_Sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Sucursales` (
  `id_sucursal` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `num_suc` varchar(45) NOT NULL,
  `domicilio` varchar(90) NOT NULL,
  `referencias` text,
  `tel_fijo` varchar(15) DEFAULT NULL,
  `tel_movil` varchar(45) DEFAULT NULL,
  `contacto` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Sucursales`
--

LOCK TABLES `t_Sucursales` WRITE;
/*!40000 ALTER TABLE `t_Sucursales` DISABLE KEYS */;
INSERT INTO `t_Sucursales` VALUES (1,'Banamex Matamoros','4333','Ruta Independencia No. 15150','Dentro Plaza Mariano Matamoros','664-999-99-99','664-99-99','Julio Salazar'),(2,'Compartamos Banco','Los Pinos','Blvd. Diaz Ordaz No. 10430','Aun lado de la CFE','664-999-99-99','664-99-99','Juana Sanchez'),(3,'Banamex La Mesa','0390','Blvd. Agua Caliente No. 140','Enfrente de Telcel 5y10 ','664-999-99-99','664-99-99','Margarita Solis'),(4,'NOMBRE SUCURSAL','NUMERO SUCURSAL','DOMICILIO SUCURSAL','REFERENCIAS','TEL FIJO','TELEFONO CELULAR','CONTACTO'),(5,'NOMBRE SUCURSAL 2','NUMERO SUCURSAL 2','DOMICILIO SUCURSAL 2','REFERENCIAS 2','TEL FIJO 2','TELEFONO CELULAR 2','CONTACTO 2'),(6,'NOMBRE SUCURSAL 2','NUMERO SUCURSAL 2','DOMICILIO SUCURSAL 2','REFERENCIAS 2','TEL FIJO 2','TELEFONO CELULAR 2','CONTACTO 2'),(7,'NOMBRE SUCURSAL 2','NUMERO SUCURSAL 2','DOMICILIO SUCURSAL 2','REFERENCIAS 2','TEL FIJO 2','TELEFONO CELULAR 2','CONTACTO 2'),(8,'NOMBRE SUCURSAL 3','NUMERO SUCURSAL 3','DOMICILIO 3','REFERENCIA 3','TELEFONO 3','CELULAR 3','CONTACTO 3');
/*!40000 ALTER TABLE `t_Sucursales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Tipo_Componente`
--

DROP TABLE IF EXISTS `t_Tipo_Componente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Tipo_Componente` (
  `id_tipo_componente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_tipo_componente`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Tipo_Componente`
--

LOCK TABLES `t_Tipo_Componente` WRITE;
/*!40000 ALTER TABLE `t_Tipo_Componente` DISABLE KEYS */;
INSERT INTO `t_Tipo_Componente` VALUES (1,'Escritorio'),(2,'Escritorio Moderno'),(3,'Portatil'),(4,'Teclado'),(5,'NoteBook');
/*!40000 ALTER TABLE `t_Tipo_Componente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Usuarios`
--

DROP TABLE IF EXISTS `t_Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Usuarios` (
  `idusuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(15) NOT NULL,
  `email` varchar(80) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cumpleanos` date NOT NULL,
  `clave` char(32) NOT NULL,
  `perfil` enum('Admin','User') NOT NULL,
  `estatus` char(1) NOT NULL DEFAULT '1',
  `id_rol` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idusuario`),
  UNIQUE KEY `email` (`email`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `t_Usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `t_Rol` (`id_rol`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Usuarios`
--

LOCK TABLES `t_Usuarios` WRITE;
/*!40000 ALTER TABLE `t_Usuarios` DISABLE KEYS */;
INSERT INTO `t_Usuarios` VALUES (1,'@admin','admin@gmail.com','Administrador','1980-10-10','81dc9bdb52d04dc20036dbd8313ed055','Admin','1',1),(2,'@usuario','usuario@gmail.com','Usuario','1990-11-11','d93591bdf7860e1e4ee2fca799911215','User','1',2);
/*!40000 ALTER TABLE `t_Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-06 21:52:11
